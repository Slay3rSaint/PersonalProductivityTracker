
<div id="header">
        <!--                        AFSASGGAGGAGAGAGAGAG                                                    -->
        <div class="action">
          <div class="profile" onclick="menuToggle();">
            <img src="https://w7.pngwing.com/pngs/722/101/png-transparent-computer-icons-user-profile-circle-abstract-miscellaneous-rim-account.png"/>
          </div>
          <div class="menu">
            <h3>someone famous</h3>
            <ul>
              <li>
                <img src="./assets/icons/user.png" /><a href="#">My profile</a>
              </li>
              <li>
                <img src="./assets/icons/edit.png" /><a href="#">Edit profile</a>
              </li>
              <li>
                <img src="./assets/icons/log-out.png" /><a
                  href="https://icanifithink.com/wp-login.php?action=logout&redirect_to=https%3A%2F%2Ficanifithink.com%2Flogin-page&_wpnonce=945a0e5cf5"
                  >Logout</a
                >
              </li>
            </ul>
          </div>
        </div>
        <script>
          function menuToggle() {
            const toggleMenu = document.querySelector(".menu");
            toggleMenu.classList.toggle("active");
          }
        </script>
                <!--                        AFSASGGAGGAGAGAGAGAG                                                    -->

      </div>