<?php include('../../Includes/db_config.php');
header('Cache-Control: no-cache, no-store, must-revalidate');
?>

<!DOCTYPE html>
<html>

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Day Planner</title>
	<link rel="stylesheet" type="text/css" href="todostyle.css">
	<link href="https://fonts.googleapis.com/css?family=Questrial" rel="stylesheet">
</head>

<body>
	<h2>Plan your day</h2>
	<form method="post" action="">
		<div class="container">
			<input type="text" placeholder="Enter task" id="userinput" name="task" required> 
			<button name="submit" class="shadow_btn" role="button">Add</button>
			</form>
			<!-- <input type="submit" name="submit" value="Add" id="enterButton" class="add_goal"> -->

		</div>
		<div class="todolist">
			<ol>
				<?php
				// Retrieve all tasks from the database
				$result = mysqli_query($conn, "SELECT t_id, task FROM todo WHERE u_id = '123' ORDER BY t_date ASC");
				if (mysqli_num_rows($result) > 0) {
					echo "<form method='post' action='delete_task.php'>";
					while ($row = mysqli_fetch_assoc($result)) {
						echo "<li>" . $row["task"] . "<button type='submit' class='done_btn' name='delete' value='" . $row["t_id"] . "'>Done</button></li>";
					}
					echo "</form>";
				}
				?>
			</ol>
		</div>
	
	<!-- <script type="text/javascript" src = "todoscript.js"></script> -->
</body>

</html>
<?php
if (isset($_POST['submit'])) {
	$uid = '123';
	$task = $_POST['task'];
	$date = date('Y-m-d');
	$sql = "INSERT INTO todo (u_id,task,t_date) VALUES ('$uid','$task','$date')";
	// Execute the insert query
	if (mysqli_query($conn, $sql)) {
		// Redirect to the same page to avoid resubmission of the form
		header("Location: {$_SERVER['REQUEST_URI']}");
		exit;
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}
?>

<!-- // Retrieve all tasks from the database
				$result = mysqli_query($conn, "SELECT t_id,task FROM todo WHERE u_id = '123' ORDER BY t_date ASC");
				if(mysqli_num_rows($result) > 0) {
					while($row = mysqli_fetch_assoc($result)) {
						// echo "<li>" . $row["task"] . "</li>";
						echo "<li>" . $row["task"] . " <button class='todobutton' data-taskid='" . $row['t_id'] . "'>Delete</button></li>";
					}
				} 
									// echo "<li>" . $row["task"] . "<button type='submit' class='todobutton' name='delete' value='" . $row["t_id"] . "'>Delete</button></li>";
-->