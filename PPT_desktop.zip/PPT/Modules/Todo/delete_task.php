<?php
include('../../Includes/db_config.php');
if (isset($_POST['delete'])) {
    $task_id = $_POST['delete'];
    $sql = "DELETE FROM todo WHERE t_id = '$task_id'";
    // Execute the delete query
    if (mysqli_query($conn, $sql)) {
        // Redirect to the same page to avoid resubmission of the form
        // header("Location: {$_SERVER['REQUEST_URI']}");
        header("Location: todo.php");
        exit;
    } else {
        echo "Error deleting task: " . mysqli_error($conn);
    }
}
?>


<!-- if (isset($_POST['taskid'])) {
    $taskId = $_POST['taskid'];
    $sql = "DELETE FROM todo WHERE id='$taskId'";
    if (mysqli_query($conn, $sql)) {
        echo "Task deleted successfully";
    } else {
        echo "Error deleting task: " . mysqli_error($conn);
    }
} -->