<?php
    // File: inc.db.php

    const HOST = 'localhost';
    const USER = 'root';
    const PWD = '';
    const DB = 'ppt';

    const CONNECT_MYSQL = 'mysql:host=' . HOST . ';dbname=' . DB;
?>