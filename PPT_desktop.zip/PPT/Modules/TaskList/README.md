# TaskList
Basic tasklist where projects and tasks can be added and removed. Experimented with basic JS and php user signup and validation functionality. 
