<?php

// include('../../Includes/db_config.php');
// // Get the amount of water from the POST request
// $amount = $_POST["amount"];

// // Get the current date in the format of YYYY-MM-DD
// $date = date("Y-m-d");

// // Insert the water intake into the database
// $sql = "INSERT INTO water (u_id, water, date) VALUES ('1', '$amount', '$date')";
// if (mysqli_query($conn, $sql)) {
//   echo "Water intake updated successfully";
// } else {
//   echo "Error updating water intake: " . mysqli_error($conn);
// }

// // Close the database connection
// mysqli_close($conn);

?>

<?php

include('../../Includes/db_config.php');

// Get the user ID
$u_id = 1; // Replace with your own code to get the user ID

// Get the amount of water from the POST request
$amount = $_POST["amount"];

// Get the current date in the format of YYYY-MM-DD
$date = date("Y-m-d");

// Check if a row exists for today's date
$sql = "SELECT * FROM water WHERE u_id='$u_id' AND date='$date'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // If a row exists, update the water intake
  $row = mysqli_fetch_assoc($result);
//   $water = $row["water"] + $amount;
  $sql = "UPDATE water SET water='$amount' WHERE u_id='$u_id' AND date='$date'";
} else {
  // If a row doesn't exist, insert a new record
  $sql = "INSERT INTO water (u_id, water, date) VALUES ('$u_id', '$amount', '$date')";
}

if (mysqli_query($conn, $sql)) {
  echo "Water intake updated successfully";
} else {
  echo "Error updating water intake: " . mysqli_error($conn);
}

// Close the database connection
mysqli_close($conn);

?>
