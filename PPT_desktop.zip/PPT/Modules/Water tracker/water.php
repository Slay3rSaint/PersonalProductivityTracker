<!DOCTYPE html>
<!--Codingthai.com-->
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="water.css" />
    <title>Drink Water</title>
</head>

<body>
    <?php
    // Replace these values with your own database credentials
    include('../../Includes/db_config.php');

    // Check for connection errors
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Set the user ID and date to retrieve data for
    $u_id = 1;
    $date = date("Y-m-d");

    // Construct the SQL query to retrieve the water data
    $sql = "SELECT water FROM water WHERE u_id=$u_id AND date='$date'";

    // Execute the query and store the result
    $result = $conn->query($sql);

    // Check for errors
    if ($conn->error) {
        die("Query failed: " . $conn->error);
    }

    // Parse the result and return the water value
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $water = $row["water"];
    } else {
        $water = 0;
    }

    // Close the MySQL connection
    $conn->close();

    // Return the water value to the JavaScript code
    echo "<input type='hidden' value=" . $water . " id='amount'>";
    ?>
    <div class="body-content">
    </div>
    <h1>Stay Hydrated..</h1>
    <h3>Goal: 2 Litres</h3>
    <!-- <div class="cup_border"></div> -->

    <div class="cup">
        <div class="remained" id="remained">
            <span id="liters"></span>
            <small>Remaining</small>
        </div>
        <div class="percentage" id="percentage"></div>
    </div>
    <p class="text">Select how many glasses of water that you drank</p>
    <div class="cups">
        <div class="cup cup-small" name="0.25" onclick="updateWater(0.25)">250 ml</div>
        <div class="cup cup-small" name="0.5" onclick="updateWater(0.5)">250 ml</div>
        <div class="cup cup-small" name="0.75" onclick="updateWater(0.75)">250 ml</div>
        <div class="cup cup-small" name="1" onclick="updateWater(1)">250 ml</div>
        <div class="cup cup-small" name="1.25" onclick="updateWater(1.25)">250 ml</div>
        <div class="cup cup-small" name="1.5" onclick="updateWater(1.5)">250 ml</div>
        <div class="cup cup-small" name="1.75" onclick="updateWater(1.75)">250 ml</div>
        <div class="cup cup-small" name="2" onclick="updateWater(2)">250 ml</div>
    </div>
    <br>
    <!-- <button class="btn" onclick="location.href='index.html'" type="button">Calculate</button> -->

    <script src="watercup.js"></script>

    <script>
        window.onload = function() {
            // Retrieve the water amount value
            var waterAmount = document.getElementById("amount").value;

            // Get all the cups
            var cups = document.getElementsByClassName("cup cup-small");

            // Loop through the cups
            for (var i = 0; i < cups.length; i++) {
                // Get the name attribute of the current cup
                var name = cups[i].getAttribute("name");

                // Check if the current cup should be clicked
                if (parseFloat(name) <= waterAmount) {
                    // Perform a click on the current cup
                    cups[i].click();
                }
            }
        };
        // function updateWater(amount) {
        //   // Send an AJAX request to the PHP script to update the water table
        //   var xhttp = new XMLHttpRequest();
        //   xhttp.onreadystatechange = function() {
        //     if (this.readyState == 4 && this.status == 200) {
        //       // Display the response from the server
        //       console.log(this.responseText);
        //     }
        //   };
        //   xhttp.open("POST", "updatewater.php", true);
        //   xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        //   xhttp.send("amount=" + amount);                                                                                var retrievedValue = document.getElementById("myHiddenField").value;

        // }

        function updateWater(amount) {
            // Send an AJAX request to the PHP script to update the water table
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Display the response from the server
                    console.log(this.responseText);
                    var water = parseFloat(this.responseText);
                    if (!isNaN(water)) {
                        // Update the UI with the new water value
                        var liters = water / 1000;
                        document.getElementById("liters").innerHTML = liters.toFixed(2);
                        var percentage = water / 20 * 100;
                        document.getElementById("percentage").style.height = percentage + "%";
                        document.getElementById("remained").style.opacity = 1;
                    }
                }
            };
            xhttp.open("POST", "updatewater.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("amount=" + amount);

            // Highlight the cups that have been clicked
            var cups = document.getElementsByClassName("cup-small");
            var total = amount;
            for (var i = 0; i < cups.length; i++) {
                var cup = cups[i];
                cup.classList.remove("selected");
                if (total >= parseFloat(cup.getAttribute("onclick").match(/\d+\.\d+/))) {
                    cup.classList.add("selected");
                    total -= parseFloat(cup.getAttribute("onclick").match(/\d+\.\d+/));
                }
            }
        }
    </script>
</body>

</html>

<!-- <div class="cups">
    <div class="cup cup-small" name="g1" onclick="updateWater(1)">250 ml</div>
    <div class="cup cup-small" name="g2" onclick="updateWater(2)">250 ml</div>
    <div class="cup cup-small" name="g3" onclick="updateWater(3)">250 ml</div>
    <div class="cup cup-small" name="g4" onclick="updateWater(4)">250 ml</div>
    <div class="cup cup-small" name="g5" onclick="updateWater(5)">250 ml</div>
    <div class="cup cup-small" name="g6" onclick="updateWater(6)">250 ml</div>
    <div class="cup cup-small" name="g7" onclick="updateWater(7)">250 ml</div>
    <div class="cup cup-small" name="g8" onclick="updateWater(8)">250 ml</div>
  </div> -->