
<!DOCTYPE html>
<!--Codingthai.com--> 
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="water.css" />
    <title>Drink Water</title>    
  </head>
  <body>
  <div class="body-content">
  </div>    
    <h1>Drink Water</h1>
    <h3>Goal: 2 Litres</h3>
    <div class="cup">
      <div class="remained" id="remained">
        <span id="liters"></span>
        <small>Remained</small>
      </div>
      <div class="percentage" id="percentage"></div>
    </div>
    <p class="text">Select how many glasses of water that you have drank</p>
    <div class="cups">
      <div class="cup cup-small">250 ml</div>
      <div class="cup cup-small">250 ml</div>
      <div class="cup cup-small">250 ml</div>
      <div class="cup cup-small">250 ml</div>
      <div class="cup cup-small">250 ml</div>
      <div class="cup cup-small">250 ml</div>
      <div class="cup cup-small">250 ml</div>
      <div class="cup cup-small">250 ml</div>
    </div>
    <br>
    <button class="btn" onclick="location.href='index.html'" type="button">Calculate</button>

    <script src="script2.js"></script>

  </body>
</html>