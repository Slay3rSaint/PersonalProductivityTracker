<?php
include('../Includes/db_config.php');
session_start();
$username = $_SESSION['username'];

// Build the SQL query
$query = "SELECT * FROM users WHERE user_id = '$username'";


// Execute the query
$result = mysqli_query($conn, $query);

//fetch the row as an array
$row = mysqli_fetch_assoc($result);

// $id = $_POST['Username'];
$photo = $row['profile_pic'];
$name = $row['name'];
$phno = $row['phno'];
$email = $row['email'];
$age = $row['age'];
$gender = $row['gender'];
$pass = $row['pass'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../CSS/registration.css" />
</head>

<body>
    <!-- <form action="" method="POST" enctype="multipart/form-data"> -->
    <div class="main">
        <div class=".reg-page">
            <div class="reg-section">
                <h2>My Profile</h2>
                <div class="avatar-holder">
                    <img src="data:image/jpeg;base64,<?php echo base64_encode($photo); ?>" alt="profile pic">
                </div>
                <div class="input-group">
                    <label class="label">Username</label>
                    <input autocomplete="off" name="Username" id="Username" class="input" type="text" value="<?php echo ($username) ?>" readonly>
                </div>
                <div class="input-group">
                    <label class="label">Name</label>
                    <input autocomplete="off" name="Name" id="Name" class="input" type="text" value="<?php echo ($name) ?>" readonly>
                </div>
                <div class="input-group">
                    <label class="label">Phone number</label>
                    <input autocomplete="off" name="Phno" id="Phno" class="input" type="number" value="<?php echo ($phno) ?>" readonly>
                </div>
                <div class="input-group">
                    <label class="label">Email address</label>
                    <input autocomplete="off" name="Email" id="Email" class="input" type="email" value="<?php echo ($email) ?>" readonly>
                </div>
                <div class="input-group">
                    <label class="label">Age</label>
                    <input autocomplete="off" name="Age" id="Age" class="input" type="number" value="<?php echo ($age) ?>" readonly>
                </div>
                <div class="input-group">
                    <label class="label">Gender</label>
                    <input autocomplete="off" name="Gender" id="Gender" class="input" type="text" value="<?php echo ($gender) ?>" readonly>
                </div>
                <div class="input-group">
                    <label class="label">Password</label>
                    <input autocomplete="off" name="Password" id="Password" class="input" type="text" value="<?php echo ($pass) ?>" readonly>
                </div>
                <button id="reg-btn" name="register" onclick="location.href='edit_profile.php'">Edit profile</button>
            </div>
        </div>
    </div>
</body>

</html>